# Handoff → Claude Code (Niklas, role 3 Product, NASA Space Apps 2026 · Planet X & SPHEREx)

## Ground rules from Niklas (follow strictly)
1. **Do NOT make any changes to the team repo** `quircedelafuente/NASA-Xsphere`: no commits, pushes, branches, PRs or edits. Work in this local folder only.
2. **Ask Niklas for permission before every action** that goes beyond reading or running locally.
3. Run and test locally first (`cd web && npm install && npm run dev` → http://localhost:5173).

## Context
- Team repo docs to read (in the browser or a read-only clone): README.md, PLAN.md, CONTRACTS.md (C1–C7), DECISIONS.md (D1–D17), roles/03-product.md.
- Niklas owns `web/src/ui|pages|styles`, `web/package.json`, `design/`, `submission/`, and the C5 URL scheme.
- Kick-off is Sat 14 Nov 15:00. Submission deadline is Sun 15 Nov 22:00.

## What exists (this folder)
- `web/` — Vite + React + TS app, working against an **in-memory mock** bundle (`src/ui/mock/`) and a **C6-compliant stub** of `<BlinkCanvas>` / `<SpectrumChart>` (`src/ui/stubs/`). The real ones are swapped in via `src/ui/viewer.ts`.
  Screens: landing (search, target cards, Aladin tab), viewer (blink/diff/side, epoch strip, play ≤ 2 fps, bands, Advanced drawer, keyboard, URL state), explain panel, states, guided tour, spectrum/light curve, share/embed, flag-a-candidate.
- `design/README.md` — breadboard, C5 URL scheme, states, visual rules, name options. `design/screens/` has screenshots.
- `submission/` — 30-second video script and project-text drafts.
- Target facts in `web/src/ui/copy.ts` are **placeholders** (`verify: true`) until Data's `science-notes.md` (C7) lands.

## NEXT TASK (approved by Niklas): map-first redesign
Niklas wants the main interface to be a **simplified map of the sky**. Images for an area only start downloading **when you zoom into / select that area** (like his BeetleNose project). The front end must look **much more user-friendly**.

Approved choices:
- **Map style:** simplified map at first (dark sky, Milky Way band, a few bright stars + constellation lines, glowing markers for the 5 targets, one search box), **fading into real survey imagery (Aladin Lite v3 / HiPS) around the patch as you zoom**.
- Zoom in or click a marker → fly to the patch → *only then* load that target's SPHEREx frames → the blink plays in place on the map, with a small floating card (name, one-liner, play/pause, Blink/Difference). "More" opens bands / spectrum / share / advanced. Zoom out → back to the map. The URL keeps following the view (C5).
- Areas without precomputed data → friendly "not processed yet" (the live backend P6 is first on the cut list).
- Reuse the existing pieces (url.ts, data.ts, BlinkCanvas stub, ExplainPanel, copy.ts, Tour, SpectrumPanel, SharePanel).

Caveats to raise with Niklas:
- This changes the team-locked core flow (D1 / C5). Niklas should tell Quirce (decider) and Giorgi (viewer) before kick-off.
- Aladin imagery only works on the real site (Vercel), not in a sandboxed preview.

## A private preview of the current version
https://claude.ai/artifact/VxE5vaiqJueVwijLYZPdHP (mock data)
