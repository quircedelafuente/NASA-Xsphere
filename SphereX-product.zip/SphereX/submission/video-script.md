# 30-second video — script & shot list (DRAFT — freeze Sun 12:00)

Hard limit **30.0 s**. Target 28 s so the export never runs over. Screen recording of the deployed site at 1920×1080. English voice-over plus burned-in English subtitles.

Facts must come from `data/science-notes.md` (C7). Any line marked ⚠️ needs Sean/Yasen to confirm.

| Time | Picture | Voice-over / subtitle | Notes |
|---|---|---|---|
| 0:00–0:04 | Two archival-style frames blinking: a dot jumps | "In 1930, Clyde Tombaugh found Pluto by blinking two photographs." | Use public-domain archival plates with credit, **or** our own recreation. If AI-generated → watermark "AI-generated" |
| 0:04–0:08 | Whole-sky map with the 5 glowing markers, slow rotation | "NASA's SPHEREx now photographs the whole sky in 102 infrared colours, every six months." | |
| 0:08–0:13 | Click Barnard's Star → fly in (map fades into real imagery) → patch blinks in place → press **D**: dark–bright dipole | "Zoom into a star. Watch it blink. Barnard's Star jumps — in Difference mode it becomes a dark–bright pair." | ⚠️ motion numbers from C7. Fly-in can be sped up in the edit |
| 0:13–0:18 | WISE 0855: card colour "Short" (empty) → tap "Long · 3.8–5 µm" → faint moving dot | "Some worlds are too cold to see — until you switch colour. WISE 0855 appears only in the deep infrared." | |
| 0:18–0:22 | Spectrum panel with H₂O / CH₄ bands highlighted | "Its spectrum shows the molecules in its air." | ⚠️ only if the real spectrum shows the features — otherwise cut to R Dra |
| 0:22–0:25 | R Draconis light-curve view | "Variable stars pulse right in front of you." | |
| 0:25–0:28 | Share → link copied → Flag a candidate | "Share any view. Flag a candidate. Your browser is a blink comparator." | Say **candidate** |
| 0:28–0:30 | End card: name, URL, team names | (silence / music tail) | No NASA logo; credit "Data: NASA/JPL-Caltech SPHEREx via IRSA" |

**Recording tips**
- Record each shot separately at 1 fps blink (≤ 2 Hz, WCAG). Speed is controlled in the edit, not in the app.
- Record on the deployed Vercel URL: the map's real imagery (Aladin) does not load in sandboxed previews.
- Hide the mouse during the blinks and zoom ×10 on the canvas. Turn on the crosshair and track.
- Fallback (if the video breaks): 7 slides that follow the same beats.
