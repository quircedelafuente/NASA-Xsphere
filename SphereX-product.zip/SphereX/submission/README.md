# Submission — U9 (owner: Niklas, texts with Yasen/Sean, technical part by Quirce)

**Deadline:** submit by **Sun 15 Nov, 22:00 local** (official close 23:59). Feature freeze 16:00. Video script frozen 12:00.

Checklist (from the role file and the Space Apps submission guide — re-read the guide before submitting):
- [ ] Project name + high-level summary
- [ ] Demo: **30-second video** (≤ 30 s, otherwise ineligible) *or* 7 slides. English, or English subtitles
- [ ] Final project link: public, **no login** (Vercel URL), works for all 5 targets, checked from a phone and another network
- [ ] Detailed description
- [ ] Use of AI ("SI") disclosed; AI-generated images/video **watermarked**
- [ ] NASA data used
- [ ] References: every external resource
- [ ] No NASA logos in generated assets · nobody under 18 on screen · "candidate", never "discovery"

Files:
- [`video-script.md`](video-script.md) — 30-second script + shot list
- [`project-texts.md`](project-texts.md) — summary, description, NASA data, AI disclosure, references (drafts)
