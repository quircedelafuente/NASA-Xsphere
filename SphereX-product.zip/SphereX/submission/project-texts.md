# Project page texts (DRAFTS)

Owners: Niklas edits · Yasen/Sean write the science parts from C7 · Quirce writes the technical paragraph.
Rules: English, "candidate" never "discovery", every number traceable to `data/science-notes.md`.

## Project name
SPHEREx Blink — *Watch the infrared sky move.*

## High-level summary (≈ 100 words)
SPHEREx Blink is a public web tool that turns NASA's SPHEREx all-sky infrared survey into a blink comparator anyone can use. Fly around a simple map of the sky, zoom into a star (or type its name or coordinates), and the same patch of sky plays back at every SPHEREx visit, like a short video. Moving objects (nearby stars, brown dwarfs) jump, and variable stars pulse. A plain-language panel explains what you are seeing. A difference mode makes 1–2-pixel motions obvious, and band chips and on-the-fly spectra use SPHEREx's 102 colours. Every view is a shareable, embeddable link. We tested it on Barnard's Star, ε Indi B, WISE 0855−0714, RW Aurigae and R Draconis.

## Detailed description

**What it does.** *(Niklas)* — The site opens on a simple, zoomable map of the sky with five glowing targets. As you zoom in, the map fades into real survey imagery. When you reach a target, or search for one by name or coordinates (decimal or sexagesimal), the site downloads only that patch's SPHEREx images and plays them in place on the map. They play as a blink, a difference image or side-by-side, with a small card that explains what to look for. Zoom out and you are back on the map. The address bar follows the view, so any view can be shared. A crosshair and the predicted track, propagated from the catalogue proper motion to each observation date, show where the object should be. A sentence states how far it moved and in which direction. Band chips switch between SPHEREx's six detectors and a combined 3.8–5 µm band where cold brown dwarfs glow. The spectrum and light-curve panel shows brightness across wavelengths and over time. A guided tour walks through five showcase objects.

**How it works.** *(Quirce — technical)* — TODO: data releases used (DR1 + QR3, wide + deep), epoch definition (> 60-day gaps; monthly for the deep field), proper-motion propagation, common 64×64 TAN grid at 6.15″/px, wavelength-matched co-adds per detector, one asinh stretch per sequence, difference images, precomputed static bundles, Vite/React front end, deployed on Vercel.

**Why it matters.** *(Sean/Yasen, from C7)* — TODO: volunteers found most known brown dwarfs and comets by blinking images (Backyard Worlds, ⚠️ number from C7). SPHEREx adds a new infrared colour axis every six months.

**Design for everyone.** *(Niklas)* — It is built first for curious non-experts arriving from a shared link. The map shows almost no controls, and expert controls stay in More → Advanced. Images download only for the patch you open, so it stays fast on a phone. It blinks at no more than 2 per second (WCAG 2.3.1), and with reduced-motion settings it starts paused in side-by-side. It uses colour-blind-safe colours and is fully keyboard-operable. Every animation has a text description.

**What's next.** — live processing of any coordinates as new SPHEREx releases arrive, a Gaia overlay, longer baselines with WISE, and collecting flagged candidates for expert review.

## NASA data used
- SPHEREx spectral images (Level 2), releases ⚠️ (from `config.yaml`): `spherex_dr1`, `spherex_dr1_deep`, `spherex_qr3`, `spherex_qr3_deep`, via NASA/IPAC Infrared Science Archive (IRSA): SIA/TAP services, cutout service, public S3 bucket `nasa-irsa-spherex`.
- ⚠️ Add here if used: WISE/AllWISE positions (archival positions), unWISE/WiseView links.

## Other data & tools (non-NASA)
- ESA Gaia DR3 astrometry ⚠️ · 2MASS positions ⚠️ · Aladin Lite v3 (CDS, Strasbourg) for the sky map · Astropy, astroquery, reproject, photutils · Vite, React, TypeScript.

## Use of AI ("SI") — disclosure
⚠️ Fill in honestly before submitting, for example: "We used AI assistants (Claude) to help plan the project, write and review code for the web interface and data scripts, and draft texts. All scientific values come from NASA/IRSA and Gaia data and the cited literature, and were checked by the team. AI-generated images or video, if any, are watermarked as AI-generated."

## References
- SPHEREx at IRSA — https://irsa.ipac.caltech.edu/Missions/spherex.html
- IRSA SPHEREx tutorials — https://caltech-ipac.github.io/irsa-tutorials/spherex/
- SPHEREx Explanatory Supplement — https://irsa.ipac.caltech.edu/data/SPHEREx/docs/SPHEREx_Expsupp.pdf
- WiseView — http://byw.tools/wiseview
- Backyard Worlds: Planet 9 (Kuchner et al. 2017) — https://ar5iv.arxiv.org/html/1705.02919
- Aladin Lite v3 — https://aladin.cds.unistra.fr/AladinLite/doc/API
- WCAG 2.3.1 Three Flashes — https://kb.daisy.org/publishing/docs/wcag/three-flashes-or-below-threshold.html
- ⚠️ Add the C7 sources (arXiv 2604.01323, arXiv 2604.22012 — Data verifies) and every per-target source.
